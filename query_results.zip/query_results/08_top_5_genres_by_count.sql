SELECT mg.Genre, COUNT(*) AS movie_count
    FROM movie_genres mg
    GROUP BY mg.Genre
    ORDER BY movie_count DESC
    LIMIT 5;