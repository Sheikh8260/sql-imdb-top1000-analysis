SELECT Year, COUNT(*) AS movie_count
    FROM movies
    GROUP BY Year
    ORDER BY Year DESC;