SELECT Year, Title, [Revenue (Millions)] AS Revenue
    FROM (
        SELECT Year, Title, [Revenue (Millions)],
               ROW_NUMBER() OVER (PARTITION BY Year ORDER BY [Revenue (Millions)] DESC) AS rn
        FROM movies
        WHERE [Revenue (Millions)] IS NOT NULL
    ) t
    WHERE rn <= 5
    ORDER BY Year DESC, rn;