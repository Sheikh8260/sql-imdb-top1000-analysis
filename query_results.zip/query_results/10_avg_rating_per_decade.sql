SELECT (Year/10)*10 AS decade, ROUND(AVG(Rating), 2) AS avg_rating, COUNT(*) AS movie_count
    FROM movies
    GROUP BY decade
    ORDER BY decade;