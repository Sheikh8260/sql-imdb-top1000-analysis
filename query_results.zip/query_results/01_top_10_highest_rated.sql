SELECT Title, Year, Rating
    FROM movies
    ORDER BY Rating DESC
    LIMIT 10;