SELECT Year, Title, Rating
    FROM (
        SELECT Year, Title, Rating,
               ROW_NUMBER() OVER (PARTITION BY Year ORDER BY Rating DESC) AS rn
        FROM movies
    ) t
    WHERE rn = 1
    ORDER BY Year DESC;