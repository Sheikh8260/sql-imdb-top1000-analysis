SELECT mg.Genre, ROUND(AVG([Runtime (Minutes)]), 2) AS avg_runtime
    FROM movies m
    JOIN movie_genres mg ON mg.Rank = m.Rank
    GROUP BY mg.Genre
    ORDER BY avg_runtime DESC;