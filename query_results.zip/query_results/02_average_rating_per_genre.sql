SELECT mg.Genre, ROUND(AVG(m.Rating), 2) AS avg_rating
    FROM movies m
    JOIN movie_genres mg ON mg.Rank = m.Rank
    GROUP BY mg.Genre
    ORDER BY avg_rating DESC;