SELECT Genre, Title, Rating
    FROM (
        SELECT mg.Genre, m.Title, m.Rating,
               ROW_NUMBER() OVER (PARTITION BY mg.Genre ORDER BY m.Rating DESC) AS rn
        FROM movie_genres mg
        JOIN movies m ON m.Rank = mg.Rank
    ) t
    WHERE rn <= 3
    ORDER BY Genre ASC, rn;