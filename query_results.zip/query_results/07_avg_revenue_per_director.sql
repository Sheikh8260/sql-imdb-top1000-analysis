SELECT Director, ROUND(AVG([Revenue (Millions)]), 2) AS avg_revenue, COUNT(*) AS movies_count
    FROM movies
    WHERE [Revenue (Millions)] IS NOT NULL
    GROUP BY Director
    HAVING COUNT(*) >= 2
    ORDER BY avg_revenue DESC
    LIMIT 10;