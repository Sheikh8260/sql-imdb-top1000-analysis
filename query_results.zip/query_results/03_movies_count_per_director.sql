SELECT Director, COUNT(*) AS movie_count
    FROM movies
    GROUP BY Director
    ORDER BY movie_count DESC
    LIMIT 10;